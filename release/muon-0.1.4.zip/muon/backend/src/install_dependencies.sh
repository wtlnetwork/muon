#!/bin/bash

# Log file location
LOG_FILE="/tmp/muon-extension.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== Starting Muon Network Tools Setup ==="

# Check if both packages are already installed. If so, exit.
if pacman -Qi hostapd &>/dev/null && pacman -Qi dnsmasq &>/dev/null; then
    log "Both hostapd and dnsmasq are already installed. Exiting."
    exit 0
fi

OS_ID="ID=steamos"
VERSION_ID=$(grep VERSION_ID /etc/os-release)

# Extension details
EXTENSION_NAME="muon-network-tools"
EXTENSION_DIR="./$EXTENSION_NAME"
EXTENSION_RELEASE="$EXTENSION_DIR/usr/lib/extension-release.d/extension-release.$EXTENSION_NAME"
EXTENSION_SRC="$PWD/$EXTENSION_NAME.raw"
EXTENSION_DEST="/var/lib/extensions/$EXTENSION_NAME.raw"

# Packages to include
PACKAGES=("hostapd" "dnsmasq")

# Create extension directory
mkdir -p "$EXTENSION_DIR/usr/lib/extension-release.d/"
touch "$EXTENSION_RELEASE"
log "Created extension directory at $EXTENSION_DIR"

# Function to fetch and extract packages
fetch_package() {
    local package_name=$1
    log "Fetching package: $package_name"

    if ! pacman -Sw --noconfirm "$package_name" >> "$LOG_FILE" 2>&1; then
        log "ERROR: Failed to sync package $package_name"
        exit 1
    fi

    local package_file
    package_file=$(ls /var/cache/pacman/pkg/${package_name}-*.pkg.tar.zst 2>/dev/null | head -n 1)

    if [ ! -f "$package_file" ]; then
        log "ERROR: Package file not found for $package_name"
        exit 1
    fi

    log "Extracting $package_file to $EXTENSION_DIR"
    tar --use-compress-program=unzstd -xvf "$package_file" -C "$EXTENSION_DIR" >> "$LOG_FILE" 2>&1
}

# Fetch all required packages
for pkg in "${PACKAGES[@]}"; do
    fetch_package "$pkg"
done

# Rebuild the extension if the OS version doesn't match
if [ ! $(grep -q "$VERSION_ID" "$EXTENSION_RELEASE") ]; then
    log "Rebuilding extension image (SquashFS)"
    
    rm -f "$EXTENSION_SRC" "$EXTENSION_RELEASE"
    echo -e "$OS_ID\n$VERSION_ID" > "$EXTENSION_RELEASE"
    chown -R root:root "$EXTENSION_DIR"

    if ! mksquashfs "$EXTENSION_DIR" "$EXTENSION_SRC" -quiet >> "$LOG_FILE" 2>&1; then
        log "ERROR: Failed to create SquashFS image"
        exit 1
    fi

    log "Extension image created at $EXTENSION_SRC"
fi

mkdir -p /var/lib/extensions
ln -sf "$EXTENSION_SRC" "$EXTENSION_DEST"
log "Linked extension: $EXTENSION_DEST"

# Ensure systemd-sysext recognizes the extension
log "Merging systemd-sysext"
if ! systemd-sysext merge >> "$LOG_FILE" 2>&1; then
    log "ERROR: Failed to merge systemd-sysext"
    exit 1
fi

log "✅ Muon Network Tools Setup Complete"